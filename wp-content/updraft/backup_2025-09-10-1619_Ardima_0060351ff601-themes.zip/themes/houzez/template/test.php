<?php
/**
 * Template Name1: Testing
 * Created by PhpStorm.
 * User: waqasriaz
 * Date: 16/13/15
 * Time: 3:27 PM
 */
get_header();

get_footer(); ?>