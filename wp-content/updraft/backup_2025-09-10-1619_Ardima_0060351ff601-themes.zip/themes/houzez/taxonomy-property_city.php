<?php
/**
 * Taxonomy Property City
 * Created by Waqas Riaz
 * Date: 08/01/16
 * Time: 4:26 PM
 * Updated: 06/03/25
 */
get_header();

get_template_part('template-parts/taxonomy/taxonomy', 'common');

get_footer();