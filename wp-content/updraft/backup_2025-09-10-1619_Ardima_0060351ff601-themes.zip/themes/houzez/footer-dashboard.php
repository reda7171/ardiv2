</div>

<?php 
//do_action( 'houzez_after_footer' );

//do_action( 'houzez_before_wp_footer' );

wp_footer(); ?>

</body>
</html>